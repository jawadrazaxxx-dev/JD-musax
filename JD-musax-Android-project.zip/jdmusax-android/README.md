# JD musax — personal Android APK

This is a Capacitor 8 Android wrapper around your supplied JD musax web app. It is for personal installation, not Play Store publishing.

## Requirements
- Node.js 22 LTS or newer
- Android Studio (current stable) with Android SDK Platform and Build Tools installed
- Android Studio's bundled JDK

## First-time setup (Windows)
1. Extract this folder.
2. Open a terminal in `jdmusax-android`.
3. Run:
   ```bat
   npm install
   npm run build:web
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. Wait for Gradle sync in Android Studio.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Click **locate** in the build notification. The debug APK is normally at:
   `android\app\build\outputs\apk\debug\app-debug.apk`

## Rebuild after editing the web app
Update files inside `web/`, then run:
```bat
npm run sync
npm run open
```
Build the APK again in Android Studio.

## App notes
- Keep `appId` (`com.jdmusax.app`) unchanged for future updates.
- This package does not contain a compiled APK; the Android SDK and Gradle build must run on a computer with Android Studio.
- Music discovery and streaming use the Audius online API and need internet.
- The app stores favorites/settings in localStorage and imported/downloaded audio in IndexedDB within the app's WebView storage.
- The existing app does not include a native background media service; reliable background playback and lock-screen controls may need extra native work.
- The page requests geolocation. If Android does not grant it, use the country selector in the app.
