import { cpSync, mkdirSync, rmSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const src = join(root, "web");
const out = join(root, "www");

if (!existsSync(join(src, "index.html"))) throw new Error("Missing web/index.html");
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });
// Copy all assets, not just the initial HTML/manifest/icon trio.
cpSync(src, out, { recursive: true });
console.log("All web assets copied to www/");
